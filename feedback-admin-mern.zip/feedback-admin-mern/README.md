# Feedback Admin Panel — MERN Stack

Responsive course feedback management application using React, React Router, Express, Node.js, and MongoDB Atlas.

## Features
- Dashboard with Course ID, Course Name, Course Duration, and Overall Feedback Rating
- Navbar routing: Dashboard and Add Feedback
- Add, update, and delete feedback
- Responsive layout and star ratings
- MongoDB Atlas connection through environment variables

## Requirements
- Node.js 18+
- MongoDB Atlas account and connection URI

## 1. Configure and run the backend
```bash
cd server
npm install
```
Copy `.env.example` to `.env`, then set `MONGODB_URI` to your MongoDB Atlas connection string.
```bash
npm run dev
```
API runs at `http://localhost:5000`.

## 2. Run the frontend
Open a second terminal:
```bash
cd client
npm install
npm run dev
```
Open the URL printed by Vite, usually `http://localhost:5173`.

## API routes
- `GET /api/feedback` — list feedback
- `GET /api/feedback/:id` — get one record
- `POST /api/feedback` — add feedback
- `PUT /api/feedback/:id` — update feedback
- `DELETE /api/feedback/:id` — delete feedback

## Notes
- Course duration is captured in the form so it can be displayed on the dashboard; it is an additional field beyond the three requested fields.
- Each feedback record represents one course submission. The dashboard average is the average of all submissions; each row shows its submission's rating.
- For deployment, add admin authentication/authorization, rate limiting, and production environment configuration.
