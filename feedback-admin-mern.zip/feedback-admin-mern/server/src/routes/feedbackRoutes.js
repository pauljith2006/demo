import { Router } from "express";
import mongoose from "mongoose";
import Feedback from "../models/Feedback.js";

const router = Router();

router.get("/", async (_req, res) => {
  try {
    res.json(await Feedback.find().sort({ createdAt: -1 }));
  } catch {
    res.status(500).json({ message: "Unable to load feedback." });
  }
});

router.get("/:id", async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid feedback ID." });
  try {
    const record = await Feedback.findById(req.params.id);
    if (!record) return res.status(404).json({ message: "Feedback not found." });
    res.json(record);
  } catch {
    res.status(500).json({ message: "Unable to load feedback." });
  }
});

router.post("/", async (req, res) => {
  const { courseName, courseDuration, comments, rating } = req.body;
  if (!courseName?.trim() || !courseDuration?.trim() || !comments?.trim() || rating === undefined || rating === null || rating === "") {
    return res.status(400).json({ message: "Please complete all fields." });
  }
  if (!Number.isFinite(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) {
    return res.status(400).json({ message: "Rating must be a number from 1 to 5." });
  }
  try {
    const record = await Feedback.create({ courseName, courseDuration, comments, rating: Number(rating) });
    res.status(201).json(record);
  } catch {
    res.status(500).json({ message: "Unable to save feedback." });
  }
});

router.put("/:id", async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid feedback ID." });
  const { courseName, courseDuration, comments, rating } = req.body;
  if (!courseName?.trim() || !courseDuration?.trim() || !comments?.trim() || rating === undefined || rating === null || rating === "") {
    return res.status(400).json({ message: "Please complete all fields." });
  }
  if (!Number.isFinite(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) {
    return res.status(400).json({ message: "Rating must be a number from 1 to 5." });
  }
  try {
    const record = await Feedback.findByIdAndUpdate(req.params.id,
      { courseName, courseDuration, comments, rating: Number(rating) },
      { new: true, runValidators: true });
    if (!record) return res.status(404).json({ message: "Feedback not found." });
    res.json(record);
  } catch {
    res.status(500).json({ message: "Unable to update feedback." });
  }
});

router.delete("/:id", async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid feedback ID." });
  try {
    const record = await Feedback.findByIdAndDelete(req.params.id);
    if (!record) return res.status(404).json({ message: "Feedback not found." });
    res.json({ message: "Feedback deleted." });
  } catch {
    res.status(500).json({ message: "Unable to delete feedback." });
  }
});

export default router;
