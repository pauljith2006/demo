import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import axios from "axios";
import { Activity, BookOpen, ChevronRight, CirclePlus, LayoutDashboard, MessageSquareText, Pencil, Search, Star, Trash2, X, Send, GraduationCap } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const api = axios.create({ baseURL: API });

function Stars({ value }) {
  return <span className="stars" aria-label={`${value} out of 5 stars`}>{[1,2,3,4,5].map(n => <Star key={n} size={15} fill={n <= Number(value) ? "currentColor" : "none"} />)} <b>{Number(value).toFixed(1)}</b></span>;
}
function Shell({ children }) {
  return <div className="app-shell">
    <aside className="sidebar">
      <Link to="/" className="brand"><span className="brand-icon"><Activity size={22}/></span><span>Course<span className="brand-light">Pulse</span><small>FEEDBACK PORTAL</small></span></Link>
      <div className="side-label">WORKSPACE</div>
      <NavLink to="/" end className={({isActive}) => `side-link ${isActive ? "active" : ""}`}><LayoutDashboard size={18}/> Dashboard</NavLink>
      <NavLink to="/add" className={({isActive}) => `side-link ${isActive ? "active" : ""}`}><CirclePlus size={18}/> Add Feedback</NavLink>
      <div className="sidebar-bottom"><div className="avatar">AD</div><div><strong>Administrator</strong><small>Feedback manager</small></div><span className="online-dot"/></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="mobile-brand"><Activity size={20}/> CoursePulse</div><div className="breadcrumb">Workspace <ChevronRight size={14}/> <span>Feedback Management</span></div><div className="top-right"><span className="status-dot"/> System operational <div className="top-avatar">AD</div></div></header>
      <div className="page-content">{children}</div>
      <footer>© 2026 CoursePulse <span>Built for better learning experiences</span></footer>
    </main>
  </div>;
}
function Dashboard({ records, loading, onEdit, onDelete, error }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => records.filter(r => `${r._id} ${r.courseName} ${r.courseDuration}`.toLowerCase().includes(search.toLowerCase())), [records, search]);
  const avg = records.length ? records.reduce((sum, r) => sum + Number(r.rating), 0) / records.length : 0;
  return <Shell><div className="page-heading"><div><div className="eyebrow">OVERVIEW</div><h1>Feedback dashboard<span className="heading-dot">.</span></h1><p>Track course experiences and turn feedback into action.</p></div><Link to="/add" className="primary-btn"><CirclePlus size={17}/> Add feedback</Link></div>
    <div className="stat-grid">
      <div className="stat-card"><div className="stat-top"><span>Total feedback</span><span className="stat-icon purple"><MessageSquareText size={19}/></span></div><div className="stat-value">{records.length}</div><div className="stat-foot">Submitted course reviews</div></div>
      <div className="stat-card"><div className="stat-top"><span>Average rating</span><span className="stat-icon gold"><Star size={19}/></span></div><div className="stat-value">{avg.toFixed(1)}<small> / 5</small></div><div className="stat-foot"><span className="tiny-stars">★★★★★</span> Across all feedback</div></div>
      <div className="stat-card"><div className="stat-top"><span>Courses reviewed</span><span className="stat-icon blue"><BookOpen size={19}/></span></div><div className="stat-value">{new Set(records.map(r => r.courseName.toLowerCase())).size}</div><div className="stat-foot">Unique course names</div></div>
    </div>
    <section className="panel">
      <div className="panel-header"><div><h2>Course feedback</h2><p>Review and manage submitted responses.</p></div><div className="searchbox"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search courses..." /></div></div>
      {error && <div className="notice error">{error}</div>}
      {loading ? <div className="empty"><div className="spinner"/><p>Loading feedback...</p></div> : filtered.length === 0 ? <div className="empty"><div className="empty-icon"><MessageSquareText size={25}/></div><h3>{search ? "No matching feedback" : "No feedback yet"}</h3><p>{search ? "Try a different search term." : "Add your first course feedback to get started."}</p>{!search && <Link to="/add" className="primary-btn"><CirclePlus size={16}/> Add feedback</Link>}</div> :
      <div className="table-wrap"><table><thead><tr><th>COURSE ID</th><th>COURSE NAME</th><th>DURATION</th><th>OVERALL RATING</th><th>ACTIONS</th></tr></thead><tbody>
        {filtered.map((r, i) => <tr key={r._id}><td><span className="course-id">CRS-{r._id.slice(-5).toUpperCase()}</span></td><td><div className="course-name"><span className="course-symbol">{r.courseName.slice(0,1).toUpperCase()}</span><span><strong>{r.courseName}</strong><small>{r.comments}</small></span></div></td><td><span className="duration">{r.courseDuration}</span></td><td><Stars value={r.rating}/></td><td><div className="actions"><button className="icon-btn edit" title="Update feedback" onClick={()=>onEdit(r)}><Pencil size={16}/></button><button className="icon-btn delete" title="Delete feedback" onClick={()=>onDelete(r)}><Trash2 size={16}/></button></div></td></tr>)}
      </tbody></table></div>}
      <div className="panel-footer"><span>Showing <b>{filtered.length}</b> of <b>{records.length}</b> feedback entries</span><span className="live-label"><span className="status-dot"/> Live data</span></div>
    </section>
  </Shell>;
}
function FeedbackForm({ initial, onSave, saving, error }) {
  const [form, setForm] = useState({ courseName: initial?.courseName || "", courseDuration: initial?.courseDuration || "", comments: initial?.comments || "", rating: initial?.rating ? String(initial.rating) : "5" });
  const [localError, setLocalError] = useState("");
  const change = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = e => {
    e.preventDefault();
    if (!form.courseName.trim() || !form.courseDuration.trim() || !form.comments.trim()) { setLocalError("Please complete all fields."); return; }
    setLocalError("");
    onSave({ ...form, rating: Number(form.rating) });
  };
  return <Shell><div className="page-heading"><div><div className="eyebrow">{initial ? "EDIT SUBMISSION" : "NEW SUBMISSION"}</div><h1>{initial ? "Update feedback" : "Add feedback"}<span className="heading-dot">.</span></h1><p>{initial ? "Make changes to the selected course feedback." : "Share a course review and help improve the learning experience."}</p></div><Link to="/" className="secondary-btn">Back to dashboard</Link></div>
    <div className="form-layout"><section className="form-panel"><div className="form-panel-head"><div className="form-icon"><MessageSquareText size={21}/></div><div><h2>Feedback details</h2><p>Fields marked with <span className="required">*</span> are required.</p></div></div>
      {(localError || error) && <div className="notice error">{localError || error}</div>}
      <form onSubmit={submit}>
        <div className="field"><label htmlFor="courseName">Course name <span className="required">*</span></label><input id="courseName" name="courseName" value={form.courseName} onChange={change} placeholder="e.g. Introduction to Web Development" maxLength="120" required/><small>Enter the full course title.</small></div>
        <div className="field"><label htmlFor="courseDuration">Course duration <span className="required">*</span></label><input id="courseDuration" name="courseDuration" value={form.courseDuration} onChange={change} placeholder="e.g. 12 weeks or 40 hours" maxLength="60" required/><small>Used in the feedback dashboard.</small></div>
        <div className="field"><label>Feedback rating <span className="required">*</span></label><div className="rating-options">{[1,2,3,4,5].map(n=><label key={n} className={`rating-choice ${Number(form.rating)===n ? "selected":""}`}><input type="radio" name="rating" value={n} checked={Number(form.rating)===n} onChange={change}/><Star size={17} fill={Number(form.rating)>=n ? "currentColor" : "none"}/><span>{n}</span></label>)}</div><small>1 = Needs improvement · 5 = Excellent</small></div>
        <div className="field"><label htmlFor="comments">Feedback comments <span className="required">*</span></label><textarea id="comments" name="comments" rows="5" value={form.comments} onChange={change} placeholder="What worked well? What could be improved?" maxLength="2000" required/><small>{form.comments.length}/2000 characters</small></div>
        <div className="form-actions"><Link to="/" className="cancel-btn">Cancel</Link><button className="primary-btn" type="submit" disabled={saving}>{saving ? "Saving..." : <>{initial ? <Pencil size={16}/> : <Send size={16}/>} {initial ? "Save changes" : "Submit feedback"}</>}</button></div>
      </form>
    </section><aside className="tip-card"><div className="tip-art"><div className="tip-orbit orbit-one"/><div className="tip-orbit orbit-two"/><div className="tip-center"><GraduationCap size={35}/></div><span className="tip-star">✦</span><span className="tip-dot">✦</span></div><div className="eyebrow">WHY IT MATTERS</div><h3>Every voice helps us grow.</h3><p>Honest course feedback helps teams celebrate what's working and improve what comes next.</p><div className="tip-rule"/><div className="tip-point"><span>01</span><div><b>Be specific</b><small>Useful comments make improvements easier.</small></div></div><div className="tip-point"><span>02</span><div><b>Be constructive</b><small>Share both strengths and opportunities.</small></div></div></aside></div>
  </Shell>;
}
function App() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const navigate = useNavigate();
  const load = async () => {
    setLoading(true); setError("");
    try { const { data } = await api.get("/feedback"); setRecords(data); }
    catch { setError("Could not connect to the API. Make sure the backend is running and MongoDB Atlas is configured."); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  const save = async data => {
    setSaving(true); setError("");
    try {
      if (editing) await api.put(`/feedback/${editing._id}`, data);
      else await api.post("/feedback", data);
      setEditing(null); await load(); navigate("/");
    } catch (e) { setError(e.response?.data?.message || "Could not save feedback. Please check the server connection."); }
    finally { setSaving(false); }
  };
  const edit = record => { setEditing(record); setError(""); navigate("/edit"); };
  const remove = async record => {
    if (!window.confirm(`Delete feedback for "${record.courseName}"? This cannot be undone.`)) return;
    setError("");
    try { await api.delete(`/feedback/${record._id}`); setRecords(old => old.filter(r => r._id !== record._id)); }
    catch (e) { setError(e.response?.data?.message || "Could not delete feedback."); }
  };
  return <Routes>
    <Route path="/" element={<Dashboard records={records} loading={loading} error={error} onEdit={edit} onDelete={remove}/>}/>
    <Route path="/add" element={<FeedbackForm key="add" onSave={save} saving={saving} error={error}/>}/>
    <Route path="/edit" element={editing ? <FeedbackForm key={editing._id} initial={editing} onSave={save} saving={saving} error={error}/> : <Dashboard records={records} loading={loading} error={error} onEdit={edit} onDelete={remove}/>}/>
    <Route path="*" element={<Dashboard records={records} loading={loading} error={error} onEdit={edit} onDelete={remove}/>}/>
  </Routes>;
}
export default App;
